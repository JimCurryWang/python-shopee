class BaseModule(object):
    """
        shopee base api
    """
    def __init__(self, client):
        self.client = client


